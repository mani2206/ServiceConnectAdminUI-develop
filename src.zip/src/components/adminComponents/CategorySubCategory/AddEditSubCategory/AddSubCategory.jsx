

import SubCategory from './addSubCategoryitems/SubCategory';

function AddSubCategory() {
    return (
        <div>
            <SubCategory />
        </div>
    );
}

export default AddSubCategory;
