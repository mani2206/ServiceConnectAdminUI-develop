import React from 'react'
import FranchiseeProfile from '../../components/commonComponents/FranchiseDetails/FranchiseeProfile'

const FranchiseProfileDetails = () => {
  return (
    <div>
        <FranchiseeProfile/>
    </div>
  )
}

export default FranchiseProfileDetails
