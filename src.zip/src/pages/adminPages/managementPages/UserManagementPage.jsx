import React from 'react'
import UserManagement from '../../../components/adminComponents/userManagement/UserManagement'

const UserManagementPage = () => {
  return (
    <div><UserManagement/></div>
  )
}

export default UserManagementPage