import React from 'react'
import AddCategory from '../../../components/adminComponents/CategorySubCategory/AddEditCategory/AddCategory'

const AddCategoryPage = () => {
  return (
    <div>
      <AddCategory/>
    </div>
  )
}

export default AddCategoryPage
