import React from 'react'
import EditCategory from '../../../components/adminComponents/CategorySubCategory/AddEditCategory/EditCategory'

const EditCategoryPage = () => {
  return (
    <div>
      <EditCategory/>
    </div>
  )
}

export default EditCategoryPage
