import React from 'react'
import SubCategoryList from '../../../components/adminComponents/CategorySubCategory/CategoryComponents/SubCategoryList'

const SubCategoryPage = () => {
  return (
    <div className='bg-blue_bg p-6 h-screen'>
        <SubCategoryList/>
    </div>
  )
}

export default SubCategoryPage