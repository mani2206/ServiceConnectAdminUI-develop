import React from 'react'
import NewAd from '../../../components/adminComponents/AdsComponents/NewAd'

const NewAdsPage = () => {
  return (
    <div className='bg-blue_bg p-6 h-screen'>
        <NewAd/>
    </div>
  )
}

export default NewAdsPage