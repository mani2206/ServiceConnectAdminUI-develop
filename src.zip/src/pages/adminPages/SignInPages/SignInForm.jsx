import React from 'react'
import AdminSignIn from '../../../components/adminComponents/signInComponents/AdminSignIn'

function SignInForm() {
  return (
    <div>
        <AdminSignIn/>
    </div>
  )
}

export default SignInForm