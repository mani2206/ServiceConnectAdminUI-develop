import React from 'react'
import FranchiseeList from '../../../components/adminComponents/FranchiseManagement/FranchiseeList'

const FranchiseDetailsTable = () => {
  return (
    <div>
      <FranchiseeList/>
    </div>
  )
}

export default FranchiseDetailsTable
