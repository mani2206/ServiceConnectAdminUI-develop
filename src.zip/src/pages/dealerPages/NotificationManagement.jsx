import React from "react";
import NotificationListCard from "../../components/dealerComponents/notificationComponent/NotificationListCard";

const NotificationManagement = () => {
  return (
    <div className="">
      <NotificationListCard />
    </div>
  );
};

export default NotificationManagement;
