import React from 'react'

import PaymentRequestForm from '../../components/dealerComponents/paymentRequestForm/PaymentRequestForm'


function PaymentRequestPage() {

  return (

    <PaymentRequestForm/>

  )
}

export default PaymentRequestPage;