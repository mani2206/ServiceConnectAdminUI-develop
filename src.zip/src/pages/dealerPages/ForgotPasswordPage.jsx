import React from 'react';
import ForgotPassword from '../../components/dealerComponents/ForgotPassword/ForgotPassword';
const ForgotPasswordPage = () => {
    return (
        <div>
            <ForgotPassword />
        </div>
    );
}

export default ForgotPasswordPage;
