import React from 'react'
import VerificationForm from '../../components/dealerComponents/VerificationFormComponent/VerificationForm.jsx'
function ServiceProviderVerificationForm() {
  return (
   <VerificationForm/>
  )
}

export default ServiceProviderVerificationForm
